# GlassShot (MV3) — Local-only Screenshot + Editor

> ✅ Local-only processing: no servers, no analytics, no network requests.

## What this extension does
- Viewport capture (Chrome API)
- Full-page capture (scroll + stitch locally)
- Area capture (selection overlay + crop)
- Editor: crop, arrows, rectangles, text, blur, highlighter
- Save as PNG/JPEG or copy to clipboard

## Platform limitations
- DRM/protected surfaces (some video players, protected overlays) may render black/blank in screenshots.
- This is a browser/OS security boundary and cannot be bypassed by extensions.

## Permissions (minimal)
- activeTab: temporary access to the current tab after user click
- scripting: inject UI overlay / selection
- downloads: save files locally
- storage: remember settings
- offscreen: create an offscreen document for clipboard + stitching helpers

Chrome docs:
- Tabs permissions & activeTab behavior: https://developer.chrome.com/docs/extensions/reference/api/tabs
- Offscreen API: https://developer.chrome.com/docs/extensions/reference/api/offscreen
- Offscreen overview: https://developer.chrome.com/blog/Offscreen-Documents-in-Manifest-v3

## Setup
1) Install deps:
```bash
npm install
