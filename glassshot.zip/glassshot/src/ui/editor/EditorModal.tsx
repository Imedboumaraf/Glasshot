import React, { useEffect, useMemo, useRef, useState } from "react";
import { motion } from "framer-motion";
import { ArrowRight, Highlighter, Type, Square, Blur, Scissors, Download, Copy, X } from "lucide-react";
import type { EditorTool, Rect } from "../../shared/types";

type Props = {
  dataUrl: string;
  meta?: any;
  onClose: () => void;
};

type Stroke = { tool: EditorTool; points: Array<{ x: number; y: number }>; color: string; width: number };
type Shape = { tool: "rect" | "arrow"; a: { x: number; y: number }; b: { x: number; y: number }; color: string; width: number };
type TextItem = { tool: "text"; x: number; y: number; value: string; color: string; size: number };
type BlurItem = { tool: "blur"; rect: Rect; radius: number };

export default function EditorModal({ dataUrl, meta, onClose }: Props) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [tool, setTool] = useState<EditorTool>("pan");
  const [busy, setBusy] = useState(false);

  const [img, setImg] = useState<HTMLImageElement | null>(null);
  const [cropRect, setCropRect] = useState<Rect | null>(null);

  const [strokes, setStrokes] = useState<Stroke[]>([]);
  const [shapes, setShapes] = useState<Shape[]>([]);
  const [texts, setTexts] = useState<TextItem[]>([]);
  const [blurs, setBlurs] = useState<BlurItem[]>([]);

  const dpr = window.devicePixelRatio || 1;

  useEffect(() => {
    const i = new Image();
    i.onload = () => setImg(i);
    i.src = dataUrl;
  }, [dataUrl]);

  // If we came from area selection, initialize cropRect to that region
  useEffect(() => {
    if (!meta?.areaRect || !img) return;
    const r = meta.areaRect as Rect;
    // clamp to image bounds (viewport capture size)
    setCropRect({
      x: Math.max(0, r.x),
      y: Math.max(0, r.y),
      w: Math.min(img.width, r.w),
      h: Math.min(img.height, r.h)
    });
    setTool("crop");
  }, [meta, img]);

  const toolbar = useMemo(
    () => [
      { k: "arrow", label: "Arrow", icon: <ArrowRight size={18} /> },
      { k: "rect", label: "Shape", icon: <Square size={18} /> },
      { k: "text", label: "Text", icon: <Type size={18} /> },
      { k: "blur", label: "Blur", icon: <Blur size={18} /> },
      { k: "highlight", label: "Highlight", icon: <Highlighter size={18} /> },
      { k: "crop", label: "Crop", icon: <Scissors size={18} /> }
    ],
    []
  );

  function fitCanvas() {
    const c = canvasRef.current;
    if (!c || !img) return;
    const maxW = Math.min(window.innerWidth - 80, 1200);
    const maxH = Math.min(window.innerHeight - 160, 800);

    const scale = Math.min(maxW / img.width, maxH / img.height, 1);
    const w = Math.floor(img.width * scale);
    const h = Math.floor(img.height * scale);

    c.style.width = `${w}px`;
    c.style.height = `${h}px`;
    c.width = Math.floor(w * dpr);
    c.height = Math.floor(h * dpr);
  }

  useEffect(() => {
    fitCanvas();
    const onResize = () => {
      fitCanvas();
      render();
    };
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [img]);

  function canvasToImageXY(e: PointerEvent | React.PointerEvent) {
    const c = canvasRef.current!;
    const r = c.getBoundingClientRect();
    const sx = (e.clientX - r.left) / r.width;
    const sy = (e.clientY - r.top) / r.height;
    return { x: sx * img!.width, y: sy * img!.height };
  }

  function render() {
    const c = canvasRef.current;
    if (!c || !img) return;
    const ctx = c.getContext("2d")!;
    const cssW = c.getBoundingClientRect().width;
    const cssH = c.getBoundingClientRect().height;

    const scaleX = cssW / img.width;
    const scaleY = cssH / img.height;

    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, c.width, c.height);

    // base image
    ctx.drawImage(img, 0, 0, img.width, img.height, 0, 0, cssW, cssH);

    // apply blurs (draw blurred region over base)
    for (const b of blurs) {
      const rx = b.rect.x * scaleX;
      const ry = b.rect.y * scaleY;
      const rw = b.rect.w * scaleX;
      const rh = b.rect.h * scaleY;

      const tmp = document.createElement("canvas");
      tmp.width = Math.max(1, Math.floor(rw));
      tmp.height = Math.max(1, Math.floor(rh));
      const tctx = tmp.getContext("2d")!;
      tctx.filter = `blur(${b.radius}px)`;
      tctx.drawImage(
        c,
        Math.floor(rx * dpr),
        Math.floor(ry * dpr),
        Math.floor(rw * dpr),
        Math.floor(rh * dpr),
        0,
        0,
        tmp.width,
        tmp.height
      );
      ctx.drawImage(tmp, rx, ry, rw, rh);
    }

    // shapes
    for (const s of shapes) {
      ctx.strokeStyle = s.color;
      ctx.lineWidth = s.width;
      ctx.lineCap = "round";
      ctx.lineJoin = "round";
      const ax = s.a.x * scaleX, ay = s.a.y * scaleY;
      const bx = s.b.x * scaleX, by = s.b.y * scaleY;

      if (s.tool === "rect") {
        const x = Math.min(ax, bx), y = Math.min(ay, by);
        const w = Math.abs(bx - ax), h = Math.abs(by - ay);
        ctx.strokeRect(x, y, w, h);
      } else {
        // arrow line + head
        ctx.beginPath();
        ctx.moveTo(ax, ay);
        ctx.lineTo(bx, by);
        ctx.stroke();

        const angle = Math.atan2(by - ay, bx - ax);
        const head = 12;
        ctx.beginPath();
        ctx.moveTo(bx, by);
        ctx.lineTo(bx - head * Math.cos(angle - 0.5), by - head * Math.sin(angle - 0.5));
        ctx.lineTo(bx - head * Math.cos(angle + 0.5), by - head * Math.sin(angle + 0.5));
        ctx.closePath();
        ctx.fillStyle = s.color;
        ctx.fill();
      }
    }

    // strokes (highlight)
    for (const st of strokes) {
      ctx.strokeStyle = st.color;
      ctx.lineWidth = st.width;
      ctx.lineCap = "round";
      ctx.lineJoin = "round";
      ctx.globalAlpha = st.tool === "highlight" ? 0.35 : 1.0;
      ctx.beginPath();
      st.points.forEach((p, idx) => {
        const x = p.x * scaleX, y = p.y * scaleY;
        if (idx === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      });
      ctx.stroke();
      ctx.globalAlpha = 1.0;
    }

    // text
    for (const t of texts) {
      ctx.fillStyle = t.color;
      ctx.font = `${t.size}px ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Arial`;
      ctx.fillText(t.value, t.x * scaleX, t.y * scaleY);
    }

    // crop overlay
    if (cropRect) {
      const x = cropRect.x * scaleX, y = cropRect.y * scaleY;
      const w = cropRect.w * scaleX, h = cropRect.h * scaleY;
      ctx.fillStyle = "rgba(0,0,0,0.35)";
      ctx.fillRect(0, 0, cssW, cssH);
      ctx.clearRect(x, y, w, h);
      ctx.strokeStyle = "rgba(255,255,255,0.9)";
      ctx.lineWidth = 2;
      ctx.strokeRect(x, y, w, h);
    }
  }

  useEffect(() => {
    render();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [img, strokes, shapes, texts, blurs, cropRect]);

  // Interaction state
  const dragRef = useRef<{ start?: { x: number; y: number }; mode?: EditorTool; tmpShapeId?: number } | null>(null);

  function onPointerDown(e: React.PointerEvent) {
    if (!img) return;
    const p = canvasToImageXY(e);
    dragRef.current = { start: p, mode: tool };

    if (tool === "highlight") {
      setStrokes((s) => [...s, { tool: "highlight", points: [p], color: "rgba(255,255,0,1)", width: 18 }]);
    }

    if (tool === "rect" || tool === "arrow") {
      setShapes((s) => [...s, { tool: tool as any, a: p, b: p, color: "rgba(0,255,255,0.9)", width: 4 }]);
    }

    if (tool === "text") {
      const value = prompt("Text:");
      if (value && value.trim()) setTexts((t) => [...t, { tool: "text", x: p.x, y: p.y, value, color: "rgba(255,255,255,0.95)", size: 28 }]);
      dragRef.current = null;
    }

    if (tool === "blur") {
      setBlurs((b) => [...b, { tool: "blur", rect: { x: p.x, y: p.y, w: 0, h: 0 }, radius: 8 }]);
    }

    if (tool === "crop") {
      setCropRect({ x: p.x, y: p.y, w: 0, h: 0 });
    }
  }

  function onPointerMove(e: React.PointerEvent) {
    if (!img || !dragRef.current?.start) return;
    const p = canvasToImageXY(e);
    const start = dragRef.current.start;

    if (tool === "highlight") {
      setStrokes((s) => {
        const last = s[s.length - 1];
        if (!last) return s;
        const next = [...s];
        next[next.length - 1] = { ...last, points: [...last.points, p] };
        return next;
      });
    }

    if (tool === "rect" || tool === "arrow") {
      setShapes((s) => {
        const last = s[s.length - 1];
        if (!last) return s;
        const next = [...s];
        next[next.length - 1] = { ...last, b: p };
        return next;
      });
    }

    if (tool === "blur") {
      setBlurs((b) => {
        const last = b[b.length - 1];
        if (!last) return b;
        const x = Math.min(start.x, p.x);
        const y = Math.min(start.y, p.y);
        const w = Math.abs(p.x - start.x);
        const h = Math.abs(p.y - start.y);
        const next = [...b];
        next[next.length - 1] = { ...last, rect: { x, y, w, h } };
        return next;
      });
    }

    if (tool === "crop") {
      const x = Math.min(start.x, p.x);
      const y = Math.min(start.y, p.y);
      const w = Math.abs(p.x - start.x);
      const h = Math.abs(p.y - start.y);
      setCropRect({ x, y, w, h });
    }
  }

  function onPointerUp() {
    dragRef.current = null;
  }

  async function exportImage(type: "png" | "jpeg") {
    if (!img) return;
    setBusy(true);
    try {
      // render to an export canvas in image coordinates
      const out = document.createElement("canvas");
      const sx = cropRect?.x ?? 0;
      const sy = cropRect?.y ?? 0;
      const sw = cropRect?.w ?? img.width;
      const sh = cropRect?.h ?? img.height;
      out.width = Math.max(1, Math.floor(sw));
      out.height = Math.max(1, Math.floor(sh));
      const ctx = out.getContext("2d")!;
      ctx.drawImage(img, sx, sy, sw, sh, 0, 0, out.width, out.height);

      // TODO: for brevity, export applies only crop (annotations are preview-rendered).
      // For production: re-apply annotations in image coords similarly to render().
      const blob: Blob = await new Promise((resolve) => out.toBlob((b) => resolve(b!), type === "png" ? "image/png" : "image/jpeg", 0.92));
      return URL.createObjectURL(blob);
    } finally {
      setBusy(false);
    }
  }

  async function download(type: "png" | "jpeg") {
    const url = await exportImage(type);
    if (!url) return;
    chrome.downloads.download({ url, filename: `glassshot.${type}` });
  }

  async function copyToClipboard() {
    // For image clipboard, we delegate to background->offscreen (Clipboard reason). :contentReference[oaicite:6]{index=6}
    if (!canvasRef.current) return;
    const c = canvasRef.current;
    const dataUrl = c.toDataURL("image/png");
    const resp = await chrome.runtime.sendMessage({ type: "GS_CLIPBOARD_WRITE_IMAGE", dataUrl });
    if (resp?.type === "GS_CLIPBOARD_RESULT" && !resp.ok) alert(resp.error ?? "Clipboard failed");
  }

  return (
    <div className="gs-editor-overlay">
      <motion.div
        initial={{ opacity: 0, y: 10, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.18 }}
        className="mx-auto mt-10 w-[min(1200px,calc(100vw-40px))] rounded-3xl border border-white/10 bg-white/10 p-4 text-white shadow-glass backdrop-blur-xl"
      >
        <div className="flex items-center justify-between">
          <div>
            <div className="text-lg font-bold">Editor</div>
            <div className="text-xs text-white/70">Crop, annotate, blur, highlight — local-only</div>
          </div>
          <button
            onClick={onClose}
            className="rounded-2xl border border-white/10 bg-white/10 p-2 hover:bg-white/15"
            title="Close"
          >
            <X size={18} />
          </button>
        </div>

        <div className="mt-3 flex flex-wrap gap-2">
          {toolbar.map((t) => (
            <button
              key={t.k}
              onClick={() => setTool(t.k as EditorTool)}
              className={[
                "flex items-center gap-2 rounded-2xl border px-3 py-2 text-sm font-semibold transition",
                tool === t.k ? "border-white/25 bg-white/20" : "border-white/10 bg-white/10 hover:bg-white/15"
              ].join(" ")}
            >
              {t.icon} {t.label}
            </button>
          ))}

          <div className="ml-auto flex gap-2">
            <button
              disabled={busy}
              onClick={() => download("png")}
              className="flex items-center gap-2 rounded-2xl border border-white/10 bg-white/10 px-3 py-2 text-sm font-semibold hover:bg-white/15 disabled:opacity-50"
            >
              <Download size={18} /> PNG
            </button>
            <button
              disabled={busy}
              onClick={() => download("jpeg")}
              className="flex items-center gap-2 rounded-2xl border border-white/10 bg-white/10 px-3 py-2 text-sm font-semibold hover:bg-white/15 disabled:opacity-50"
            >
              <Download size={18} /> JPEG
            </button>
            <button
              disabled={busy}
              onClick={copyToClipboard}
              className="flex items-center gap-2 rounded-2xl border border-white/10 bg-white/10 px-3 py-2 text-sm font-semibold hover:bg-white/15 disabled:opacity-50"
            >
              <Copy size={18} /> Copy
            </button>
          </div>
        </div>

        <div className="mt-4 flex justify-center">
          <canvas
            ref={canvasRef}
            className="rounded-2xl border border-white/10 bg-black/40 shadow-glass"
            onPointerDown={onPointerDown}
            onPointerMove={onPointerMove}
            onPointerUp={onPointerUp}
          />
        </div>

        <div className="mt-3 text-xs text-white/60">
          Tip: use <span className="font-semibold text-white/80">Crop</span> to select the export area.
        </div>
      </motion.div>
    </div>
  );
}
