import React from "react";

export function Card(props: React.PropsWithChildren<{ className?: string }>) {
  return (
    <div
      className={[
        "rounded-2xl border border-white/10 bg-white/10 shadow-glass backdrop-blur-xl",
        "text-white",
        props.className ?? ""
      ].join(" ")}
    >
      {props.children}
    </div>
  );
}

export function PrimaryButton(props: React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      {...props}
      className={[
        "w-full rounded-2xl px-4 py-3 font-semibold",
        "bg-white/15 hover:bg-white/20 active:scale-[0.99]",
        "border border-white/10",
        "transition",
        props.className ?? ""
      ].join(" ")}
    />
  );
}
