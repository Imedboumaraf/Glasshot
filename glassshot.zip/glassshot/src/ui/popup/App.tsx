import React, { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Camera, Crop, ScrollText } from "lucide-react";
import { Card, PrimaryButton } from "./components";
import EditorModal from "../editor/EditorModal";

type OpenEditorEvent = CustomEvent<{ type: "GS_OPEN_EDITOR"; dataUrl: string; meta?: any }>;

export default function App() {
  const [editorOpen, setEditorOpen] = useState(false);
  const [imageDataUrl, setImageDataUrl] = useState<string | null>(null);
  const [meta, setMeta] = useState<any>(null);

  useEffect(() => {
    const handler = (e: Event) => {
      const ce = e as OpenEditorEvent;
      setImageDataUrl(ce.detail.dataUrl);
      setMeta(ce.detail.meta ?? null);
      setEditorOpen(true);
    };
    window.addEventListener("GS_OPEN_EDITOR", handler as any);
    return () => window.removeEventListener("GS_OPEN_EDITOR", handler as any);
  }, []);

  async function request(type: "GS_REQUEST_VIEWPORT" | "GS_REQUEST_FULLPAGE" | "GS_REQUEST_AREA") {
    await chrome.runtime.sendMessage({ type });
    window.close();
  }

  return (
    <div className="w-[360px] p-3 text-white">
      <Card className="p-4">
        <div className="flex items-center justify-between">
          <div>
            <div className="text-lg font-bold tracking-tight">GlassShot</div>
            <div className="text-xs text-white/70">Local-only screenshots + editor</div>
          </div>
          <div className="rounded-2xl border border-white/10 bg-white/10 px-2 py-1 text-[10px] text-white/70">
            MV3
          </div>
        </div>

        <div className="mt-4 space-y-2">
          <PrimaryButton onClick={() => request("GS_REQUEST_VIEWPORT")}>
            <div className="flex items-center gap-2">
              <Camera size={18} /> Capture viewport
            </div>
          </PrimaryButton>

          <PrimaryButton onClick={() => request("GS_REQUEST_FULLPAGE")}>
            <div className="flex items-center gap-2">
              <ScrollText size={18} /> Capture full page
            </div>
          </PrimaryButton>

          <PrimaryButton onClick={() => request("GS_REQUEST_AREA")}>
            <div className="flex items-center gap-2">
              <Crop size={18} /> Select area
            </div>
          </PrimaryButton>
        </div>
      </Card>

      <AnimatePresence>
        {editorOpen && imageDataUrl && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50"
          >
            <EditorModal dataUrl={imageDataUrl} meta={meta} onClose={() => setEditorOpen(false)} />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
