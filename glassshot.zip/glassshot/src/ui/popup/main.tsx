import React from "react";
import { createRoot } from "react-dom/client";
import "./../editor/editor.css";
import "./popup.css";
import App from "./App";

createRoot(document.getElementById("root")!).render(<App />);
