import type { BgToOffscreen, OffscreenToBg } from "../shared/messages";
import { dataUrlToBlob, blobToDataUrl } from "../shared/image";

async function stitchFullPage(parts: Array<{ dataUrl: string; x: number; y: number; w: number; h: number }>, fullW: number, fullH: number, dpr: number) {
  const canvas = document.createElement("canvas");
  canvas.width = Math.round(fullW * dpr);
  canvas.height = Math.round(fullH * dpr);
  const ctx = canvas.getContext("2d")!;
  ctx.imageSmoothingEnabled = true;

  for (const p of parts) {
    const blob = await dataUrlToBlob(p.dataUrl);
    const bmp = await createImageBitmap(blob);
    ctx.drawImage(
      bmp,
      0,
      0,
      bmp.width,
      bmp.height,
      Math.round(p.x * dpr),
      Math.round(p.y * dpr),
      Math.round(p.w * dpr),
      Math.round(p.h * dpr)
    );
    bmp.close?.();
  }

  const outBlob: Blob = await new Promise((resolve) => canvas.toBlob((b) => resolve(b!), "image/png"));
  return await blobToDataUrl(outBlob);
}

async function writeImageToClipboard(dataUrl: string) {
  const blob = await dataUrlToBlob(dataUrl);
  // ClipboardItem is supported in Chromium-based browsers.
  const item = new ClipboardItem({ [blob.type]: blob });
  await navigator.clipboard.write([item]);
}

chrome.runtime.onMessage.addListener((msg: BgToOffscreen, _sender, sendResponse) => {
  (async () => {
    try {
      if (msg.type === "GS_STITCH_FULLPAGE") {
        const dataUrl = await stitchFullPage(msg.parts, msg.fullW, msg.fullH, msg.dpr);
        const resp: OffscreenToBg = { type: "GS_STITCH_RESULT", dataUrl };
        sendResponse(resp);
        return;
      }
      if (msg.type === "GS_CLIPBOARD_WRITE_IMAGE") {
        await writeImageToClipboard(msg.dataUrl);
        const resp: OffscreenToBg = { type: "GS_CLIPBOARD_RESULT", ok: true };
        sendResponse(resp);
        return;
      }
      sendResponse({ type: "GS_CLIPBOARD_RESULT", ok: false, error: "Unknown offscreen op" } satisfies OffscreenToBg);
    } catch (e: any) {
      sendResponse({ type: "GS_CLIPBOARD_RESULT", ok: false, error: e?.message ?? String(e) } satisfies OffscreenToBg);
    }
  })();
  return true;
});
