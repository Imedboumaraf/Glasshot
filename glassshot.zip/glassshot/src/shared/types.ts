export type Rect = { x: number; y: number; w: number; h: number };

export type EditorTool = "pan" | "crop" | "rect" | "arrow" | "text" | "blur" | "highlight";
