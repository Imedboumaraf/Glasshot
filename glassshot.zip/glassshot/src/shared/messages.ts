export type CaptureMode = "viewport" | "fullpage" | "area";

export type BgToContent =
  | { type: "GS_START_AREA_SELECT" }
  | { type: "GS_START_FULLPAGE" }
  | { type: "GS_OPEN_EDITOR"; dataUrl: string; meta?: Record<string, unknown> };

export type ContentToBg =
  | { type: "GS_CAPTURE_VIEWPORT" }
  | { type: "GS_CAPTURE_VIEWPORT_AT"; x: number; y: number }
  | { type: "GS_AREA_SELECTED"; rect: { x: number; y: number; w: number; h: number } }
  | { type: "GS_FULLPAGE_PART"; part: { dataUrl: string; x: number; y: number; w: number; h: number } }
  | { type: "GS_FULLPAGE_DONE"; page: { fullW: number; fullH: number; dpr: number } };

export type BgToOffscreen =
  | { type: "GS_STITCH_FULLPAGE"; parts: Array<{ dataUrl: string; x: number; y: number; w: number; h: number }>; fullW: number; fullH: number; dpr: number }
  | { type: "GS_CLIPBOARD_WRITE_IMAGE"; dataUrl: string };

export type OffscreenToBg =
  | { type: "GS_STITCH_RESULT"; dataUrl: string }
  | { type: "GS_CLIPBOARD_RESULT"; ok: boolean; error?: string };
