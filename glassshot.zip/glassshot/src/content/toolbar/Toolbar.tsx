import React, { useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import { motion, AnimatePresence } from "framer-motion";
import { Camera, Crop, FileDown, Copy, X, ScrollText } from "lucide-react";

function GlassButton(props: React.ButtonHTMLAttributes<HTMLButtonElement> & { label: string }) {
  const { label, ...rest } = props;
  return (
    <button
      {...rest}
      style={{
        all: "unset",
        cursor: "pointer",
        display: "flex",
        alignItems: "center",
        gap: 10,
        padding: "10px 12px",
        borderRadius: 14,
        border: "1px solid rgba(255,255,255,0.20)",
        background: "rgba(255,255,255,0.10)",
        color: "rgba(255,255,255,0.92)",
        boxShadow: "0 10px 30px rgba(0,0,0,0.25)"
      }}
      title={label}
    />
  );
}

export function mountToolbar() {
  if (document.getElementById("gs-toolbar-root")) return;

  const host = document.createElement("div");
  host.id = "gs-toolbar-root";
  host.className = "gs-root";
  host.style.position = "fixed";
  host.style.top = "16px";
  host.style.right = "16px";
  host.style.zIndex = "2147483647";
  host.style.fontFamily = "ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Arial";

  const shadow = host.attachShadow({ mode: "open" });
  const mount = document.createElement("div");
  shadow.appendChild(mount);

  const style = document.createElement("style");
  style.textContent = `
    .panel{
      width: 280px;
      border-radius: 18px;
      border: 1px solid rgba(255,255,255,0.18);
      background: rgba(20, 24, 35, 0.55);
      box-shadow: 0 20px 60px rgba(0,0,0,0.35);
      backdrop-filter: blur(14px);
      padding: 12px;
      color: rgba(255,255,255,0.92);
    }
    .row{ display:flex; gap:10px; flex-wrap:wrap; }
    .title{ font-weight:700; font-size:13px; letter-spacing:0.2px; opacity:0.95; }
    .sub{ font-size:12px; opacity:0.75; margin-top:2px; }
    .top{ display:flex; align-items:center; justify-content:space-between; margin-bottom:10px; }
  `;
  shadow.appendChild(style);

  document.documentElement.appendChild(host);

  const root = createRoot(mount);
  root.render(<Toolbar />);
}

function Toolbar() {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const actions = useMemo(
    () => [
      {
        label: "Viewport",
        icon: <Camera size={18} />,
        onClick: async () => chrome.runtime.sendMessage({ type: "GS_REQUEST_VIEWPORT" })
      },
      {
        label: "Full page",
        icon: <ScrollText size={18} />,
        onClick: async () => chrome.runtime.sendMessage({ type: "GS_REQUEST_FULLPAGE" })
      },
      {
        label: "Area",
        icon: <Crop size={18} />,
        onClick: async () => chrome.runtime.sendMessage({ type: "GS_REQUEST_AREA" })
      }
    ],
    []
  );

  return (
    <>
      <motion.button
        onClick={() => setOpen((v) => !v)}
        whileTap={{ scale: 0.98 }}
        style={{
          all: "unset",
          cursor: "pointer",
          width: 46,
          height: 46,
          borderRadius: 16,
          display: "grid",
          placeItems: "center",
          border: "1px solid rgba(255,255,255,0.20)",
          background: "rgba(20,24,35,0.55)",
          color: "rgba(255,255,255,0.92)",
          boxShadow: "0 20px 60px rgba(0,0,0,0.35)",
          backdropFilter: "blur(14px)"
        }}
        title="GlassShot"
      >
        <Camera size={20} />
      </motion.button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -8, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -8, scale: 0.98 }}
            transition={{ duration: 0.18 }}
            className="panel"
            style={{ marginTop: 10 }}
          >
            <div className="top">
              <div>
                <div className="title">GlassShot</div>
                <div className="sub">Local-only capture + editor</div>
              </div>
              <button
                onClick={() => setOpen(false)}
                style={{
                  all: "unset",
                  cursor: "pointer",
                  padding: 6,
                  borderRadius: 10,
                  border: "1px solid rgba(255,255,255,0.14)"
                }}
                title="Close"
              >
                <X size={16} />
              </button>
            </div>

            <div className="row">
              {actions.map((a) => (
                <GlassButton key={a.label} label={a.label} onClick={a.onClick}>
                  {a.icon}
                  <span style={{ fontSize: 13, fontWeight: 650 }}>{a.label}</span>
                </GlassButton>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
