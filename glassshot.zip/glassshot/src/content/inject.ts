import "./toolbar/toolbar.css";
import { mountToolbar } from "./toolbar/Toolbar";
import { startSelection } from "./selection/selection";
import { startFullPageCapture } from "./fullpage/fullpage";
import type { BgToContent } from "../shared/messages";

mountToolbar();

chrome.runtime.onMessage.addListener((msg: BgToContent) => {
  if (msg.type === "GS_START_AREA_SELECT") {
    startSelection();
  }
  if (msg.type === "GS_START_FULLPAGE") {
    startFullPageCapture();
  }
  if (msg.type === "GS_OPEN_EDITOR") {
    window.dispatchEvent(new CustomEvent("GS_OPEN_EDITOR", { detail: msg }));
  }
});
