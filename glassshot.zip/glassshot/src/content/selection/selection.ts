let overlay: HTMLDivElement | null = null;

export function startSelection() {
  if (overlay) return;

  overlay = document.createElement("div");
  overlay.style.position = "fixed";
  overlay.style.inset = "0";
  overlay.style.zIndex = "2147483647";
  overlay.style.cursor = "crosshair";
  overlay.style.background = "rgba(0,0,0,0.15)";
  overlay.style.backdropFilter = "blur(2px)";

  const box = document.createElement("div");
  box.style.position = "absolute";
  box.style.border = "2px solid rgba(255,255,255,0.9)";
  box.style.borderRadius = "12px";
  box.style.boxShadow = "0 10px 30px rgba(0,0,0,0.35)";
  box.style.background = "rgba(255,255,255,0.08)";
  overlay.appendChild(box);

  let startX = 0, startY = 0, dragging = false;

  function onDown(e: PointerEvent) {
    dragging = true;
    startX = e.clientX;
    startY = e.clientY;
    box.style.left = `${startX}px`;
    box.style.top = `${startY}px`;
    box.style.width = `0px`;
    box.style.height = `0px`;
    overlay!.setPointerCapture(e.pointerId);
  }

  function onMove(e: PointerEvent) {
    if (!dragging) return;
    const x = Math.min(e.clientX, startX);
    const y = Math.min(e.clientY, startY);
    const w = Math.abs(e.clientX - startX);
    const h = Math.abs(e.clientY - startY);
    box.style.left = `${x}px`;
    box.style.top = `${y}px`;
    box.style.width = `${w}px`;
    box.style.height = `${h}px`;
  }

  async function onUp(e: PointerEvent) {
    if (!dragging) return;
    dragging = false;
    const rect = box.getBoundingClientRect();
    cleanup();
    // Send selection to background; editor will crop from viewport capture.
    chrome.runtime.sendMessage({
      type: "GS_AREA_SELECTED",
      rect: { x: rect.x, y: rect.y, w: rect.width, h: rect.height }
    });
  }

  function onKey(e: KeyboardEvent) {
    if (e.key === "Escape") cleanup();
  }

  function cleanup() {
    window.removeEventListener("keydown", onKey, true);
    overlay?.remove();
    overlay = null;
  }

  overlay.addEventListener("pointerdown", onDown);
  overlay.addEventListener("pointermove", onMove);
  overlay.addEventListener("pointerup", onUp);
  window.addEventListener("keydown", onKey, true);

  document.documentElement.appendChild(overlay);
}
