function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

export async function startFullPageCapture() {
  const dpr = window.devicePixelRatio || 1;
  const doc = document.documentElement;

  const fullW = Math.max(doc.scrollWidth, document.body?.scrollWidth ?? 0);
  const fullH = Math.max(doc.scrollHeight, document.body?.scrollHeight ?? 0);

  const viewportW = window.innerWidth;
  const viewportH = window.innerHeight;

  const parts: Array<{ dataUrl: string; x: number; y: number; w: number; h: number }> = [];

  const prevX = window.scrollX;
  const prevY = window.scrollY;

  // Best-effort: hide scrollbars while capturing (reduces seams)
  const prevOverflow = doc.style.overflow;
  doc.style.overflow = "hidden";

  try {
    for (let y = 0; y < fullH; y += viewportH) {
      window.scrollTo(0, y);
      await sleep(120);

      const resp = await chrome.runtime.sendMessage({ type: "GS_CAPTURE_VIEWPORT" });
      if (!resp?.ok) throw new Error(resp?.error ?? "capture failed");

      const currentY = window.scrollY;
      parts.push({
        dataUrl: resp.dataUrl,
        x: 0,
        y: currentY,
        w: viewportW,
        h: viewportH
      });
    }
  } finally {
    doc.style.overflow = prevOverflow;
    window.scrollTo(prevX, prevY);
  }

  // Ask background to stitch via offscreen document
  await chrome.runtime.sendMessage({ type: "GS_STITCH_FROM_BG", parts, fullW, fullH, dpr });
}
