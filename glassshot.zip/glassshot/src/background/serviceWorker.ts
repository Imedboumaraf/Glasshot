import type { BgToContent, ContentToBg } from "../shared/messages";
import { ensureOffscreen, sendToOffscreen } from "./offscreenBridge";

async function getActiveTabId(): Promise<number> {
  const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  if (!tab?.id) throw new Error("No active tab");
  return tab.id;
}

async function captureViewport(): Promise<string> {
  // Requires activeTab or host permissions; we use activeTab (user gesture). :contentReference[oaicite:3]{index=3}
  const dataUrl = await chrome.tabs.captureVisibleTab({ format: "png" });
  return dataUrl;
}

async function sendToActiveTab(msg: BgToContent) {
  const tabId = await getActiveTabId();
  await chrome.tabs.sendMessage(tabId, msg);
}

chrome.runtime.onMessage.addListener((msg: ContentToBg, _sender, sendResponse) => {
  (async () => {
    try {
      if (msg.type === "GS_CAPTURE_VIEWPORT") {
        const dataUrl = await captureViewport();
        sendResponse({ ok: true, dataUrl });
        return;
      }

      if (msg.type === "GS_AREA_SELECTED") {
        // Ask content script to capture viewport, then editor will crop.
        const dataUrl = await captureViewport();
        await sendToActiveTab({ type: "GS_OPEN_EDITOR", dataUrl, meta: { areaRect: msg.rect } });
        sendResponse({ ok: true });
        return;
      }

      if (msg.type === "GS_FULLPAGE_DONE") {
        // Content script will already have sent parts via GS_FULLPAGE_PART to a buffer.
        sendResponse({ ok: true });
        return;
      }

      // full-page stitching request from popup/toolbar
      if ((msg as any).type === "GS_REQUEST_FULLPAGE") {
        await sendToActiveTab({ type: "GS_START_FULLPAGE" });
        sendResponse({ ok: true });
        return;
      }

      if ((msg as any).type === "GS_REQUEST_AREA") {
        await sendToActiveTab({ type: "GS_START_AREA_SELECT" });
        sendResponse({ ok: true });
        return;
      }

      if ((msg as any).type === "GS_REQUEST_VIEWPORT") {
        const dataUrl = await captureViewport();
        await sendToActiveTab({ type: "GS_OPEN_EDITOR", dataUrl });
        sendResponse({ ok: true });
        return;
      }

      // Full-page parts are forwarded to offscreen to stitch
      if ((msg as any).type === "GS_STITCH_FROM_BG") {
        const { parts, fullW, fullH, dpr } = (msg as any);
        await ensureOffscreen(chrome.offscreen.Reason.BLOBS, "Stitch captured images into a single PNG.");
        const stitched = await sendToOffscreen({ type: "GS_STITCH_FULLPAGE", parts, fullW, fullH, dpr });
        if (stitched.type !== "GS_STITCH_RESULT") throw new Error("Stitch failed");
        await sendToActiveTab({ type: "GS_OPEN_EDITOR", dataUrl: stitched.dataUrl, meta: { fullpage: true } });
        sendResponse({ ok: true });
        return;
      }

      if ((msg as any).type === "GS_CLIPBOARD_WRITE_IMAGE") {
        const { dataUrl } = (msg as any);
        await ensureOffscreen(chrome.offscreen.Reason.CLIPBOARD, "Copy image to clipboard locally.");
        const resp = await sendToOffscreen({ type: "GS_CLIPBOARD_WRITE_IMAGE", dataUrl });
        sendResponse(resp);
        return;
      }

      sendResponse({ ok: false, error: "Unknown message" });
    } catch (e: any) {
      sendResponse({ ok: false, error: e?.message ?? String(e) });
    }
  })();
  return true;
});
