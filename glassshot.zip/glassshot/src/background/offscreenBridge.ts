import type { BgToOffscreen, OffscreenToBg } from "../shared/messages";

const OFFSCREEN_URL = chrome.runtime.getURL("offscreen.html");

async function hasOffscreen(): Promise<boolean> {
  // Chrome provides getContexts in newer versions
  if ("getContexts" in chrome.runtime) {
    // @ts-expect-error - typing lags behind Chrome sometimes
    const contexts = await chrome.runtime.getContexts({
      contextTypes: ["OFFSCREEN_DOCUMENT"],
      documentUrls: [OFFSCREEN_URL]
    });
    return contexts?.length > 0;
  }
  return false;
}

export async function ensureOffscreen(reason: chrome.offscreen.Reason, justification: string) {
  const exists = await hasOffscreen();
  if (exists) return;
  await chrome.offscreen.createDocument({
    url: "offscreen.html",
    reasons: [reason],
    justification
  });
}

export function sendToOffscreen(msg: BgToOffscreen): Promise<OffscreenToBg> {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(msg, (resp: OffscreenToBg) => resolve(resp));
  });
}
