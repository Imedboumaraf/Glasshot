import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { resolve } from "path";

export default defineConfig({
  plugins: [react()],
  build: {
    outDir: "dist",
    emptyOutDir: true,
    rollupOptions: {
      input: {
        popup: resolve(__dirname, "src/ui/popup/index.html"),
        // content + background are built as separate entries
        serviceWorker: resolve(__dirname, "src/background/serviceWorker.ts"),
        inject: resolve(__dirname, "src/content/inject.ts"),
        offscreen: resolve(__dirname, "src/offscreen/offscreen.ts")
      },
      output: {
        entryFileNames: (chunk) => {
          if (chunk.name === "serviceWorker") return "serviceWorker.js";
          if (chunk.name === "inject") return "inject.js";
          if (chunk.name === "offscreen") return "offscreen.js";
          return "assets/[name].js";
        }
      }
    }
  }
});
